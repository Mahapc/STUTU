<?php
// Database connection
require("conn.php");

// Check connection
if ($con->connect_error) {
    die(json_encode(["error" => "Connection failed: " . $con->connect_error]));
}

// Check if the request is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["email"], $_POST["name"], $_POST["password"], $_POST["gender"], $_POST["age"])) {
        $email = $_POST["email"];
        $name = $_POST["name"];
        $password = $_POST["password"];
        $age = $_POST["age"];
        $gender = $_POST["gender"];
        // Check if email already exists
        $check_sql = "SELECT email FROM student WHERE email = ?";
        $stmt = $con->prepare($check_sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            echo json_encode(["error" => "Email already exists"]);
        } else {
            // Insert new student record
            $insert_sql = "INSERT INTO student (email, name, password, gender, age) VALUES (?, ?, ?, ?, ?)";
            $stmt = $con->prepare($insert_sql);
            $stmt->bind_param("ssssi", $email, $name, $password, $gender, $age);

            if ($stmt->execute()) {
                echo json_encode(["success" => "Account created successfully"]);
            } else {
                echo json_encode(["error" => "Failed to create account"]);
            }
        }

        $stmt->close();
    } else {
        echo json_encode(["error" => "Missing parameters"]);
    }
} else {
    echo json_encode(["error" => "Invalid request method"]);
}

$con->close();
?>
