<?php
// Database connection details
require("conn.php");

// Check connection
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["email"])) {
        $email = $_POST["email"];

        $sql = "SELECT gender, age FROM student WHERE email = ?";
        $stmt = $con->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            echo json_encode(["gender" => $row["gender"], "age" => $row["age"]]);
        } else {
            echo json_encode(["error" => "No student found with this email"]);
        }
    } else {
        echo json_encode(["error" => "Missing email parameter"]);
    }
} else {
    echo json_encode(["error" => "Invalid request method"]);
}

$con->close();
?>
