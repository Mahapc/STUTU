<?php
include 'conn.php'; // Include database connection

header("Content-Type: application/json");

$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data['id']) || !isset($data['status'])) {
    echo json_encode(["success" => false, "message" => "Missing required parameters"]);
    exit;
}

$id = $data['id'];
$status = $data['status'];
$link = isset($data['link']) ? $data['link'] : null;

try {
    if ($status == "success" && $link) {
        $stmt = $con->prepare("UPDATE request SET status = ?, link = ? WHERE id = ?");
        $stmt->bind_param("ssi", $status, $link, $id);
    } else {
        $stmt = $con->prepare("UPDATE request SET status = ?, link = NULL WHERE id = ?");
        $stmt->bind_param("si", $status, $id);
    }

    if ($stmt->execute()) {
        echo json_encode(["success" => true, "message" => "Request updated successfully"]);
    } else {
        echo json_encode(["success" => false, "message" => "Failed to update request"]);
    }

    $stmt->close();
    $con->close();
} catch (Exception $e) {
    echo json_encode(["success" => false, "message" => "Error: " . $e->getMessage()]);
}
?>
