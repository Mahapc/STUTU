<?php
include 'conn.php'; // Ensure this file contains your database connection

header('Content-Type: application/json');

$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data['tutor'])) {
    echo json_encode(["error" => "Tutor parameter missing"]);
    exit;
}

$tutor = $data['tutor'];

$response = [];

$sql = "SELECT c.id as id, c.course_name AS course_name, 
        (SELECT COUNT(*) FROM request r WHERE r.course = c.id and r.status='pending') AS count
        FROM course c
        WHERE c.tutor = ?";

$stmt = $con->prepare($sql);
$stmt->bind_param("s", $tutor);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $response[] = [
        "id" => $row['id'],
        "course_name" => $row['course_name'],
        "count" => (int)$row['count']
    ];
}

$stmt->close();
$con->close();

echo json_encode(["courses" => $response]);
?>
