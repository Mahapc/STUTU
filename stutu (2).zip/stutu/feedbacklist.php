<?php
// Database connection details
require("conn.php");

// Check connection
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['email'])) {
    $email = $_POST['email'];

    $sql = "SELECT s.name, f.star, f.reason 
            FROM feedback f 
            JOIN student s ON f.student = s.email 
            WHERE f.tutor = ?";
    
    $stmt = $con->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    $feedbacks = [];

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $feedbacks[] = [
                "name" => $row["name"],
                "star" => $row["star"],
                "reason" => $row["reason"]
            ];
        }
    }

    echo json_encode($feedbacks);
    
    $stmt->close();
} else {
    echo json_encode(["error" => "Invalid request or missing parameters"]);
}

$con->close();
?>
