<?php
include 'conn.php'; // Include database connection

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents("php://input"), true);

    if (isset($input['student'])) {
        $student = $input['student'];

        $sql = "SELECT 
                    t.name AS tutor, 
                    c.course_name AS course, 
                    r.date, 
                    r.start, 
                    r.end, 
                    r.status, 
                    CASE 
                        WHEN r.status = 'success' THEN r.link 
                        ELSE NULL 
                    END AS link 
                FROM request r
                JOIN tutor t ON t.email = r.tutor
                JOIN course c ON c.id = r.course
                WHERE r.student = ?";

        $stmt = $con->prepare($sql);
        $stmt->bind_param("s", $student);
        $stmt->execute();
        $result = $stmt->get_result();

        $requests = [];
        while ($row = $result->fetch_assoc()) {
            $requests[] = $row;
        }

        echo json_encode(["requests" => $requests]);
    } else {
        echo json_encode(["error" => "Student parameter missing"]);
    }
} else {
    echo json_encode(["error" => "Invalid request method"]);
}
?>
