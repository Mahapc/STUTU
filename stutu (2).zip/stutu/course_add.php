<?php
// Database connection details
require("conn.php");

// Check connection
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}

// Directory where uploaded videos will be saved
$uploadDir = "videos/";

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['video'])) {
    $file = $_FILES['video'];
    $fileName = basename($file['name']);
    $uploadPath = $uploadDir.$fileName;

    if (move_uploaded_file($file['tmp_name'], $uploadPath)) {
        // File uploaded successfully, insert path into database
        if (isset($_POST['tutor']) && isset($_POST['subject']) && isset($_POST['sub_subj']) && isset($_POST['description'])) {
            $tutor = $_POST['tutor'];
            $subject = $_POST['subject'];
            $sub_subj = $_POST['sub_subj'];
            $description = $_POST['description'];
            $course = $_POST['course'];
            if($subject=="physics"){
                $sub_subj=null;
            }

            $sql = "INSERT INTO course (course_name,tutor, subject, sub_subj, video, description) VALUES ('$course','$tutor', '$subject', '$sub_subj', '$fileName', '$description')";

            if ($con->query($sql) === TRUE) {
                echo "Course details inserted successfully";
            } else {
                echo "Error inserting course details: " . $con->error;
            }
        } else {
            echo "Missing required fields";
        }
    } else {
        echo "Error uploading the file";
    }
} else {
    echo "Invalid request";
}

$con->close();
?>
