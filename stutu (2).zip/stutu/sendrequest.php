<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Decode the JSON data
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (isset($data["course"], $data["tutor"], $data["student"], $data["status"], $data["date"], $data["start"], $data["end"])) {
        $course = $data["course"];
        $tutor = $data["tutor"];
        $student = $data["student"];
        $status = $data["status"];
        $date = $data["date"];
        $start = $data["start"];
        $end = $data["end"];

        // Establish the database connection
        require("conn.php");

        // Check connection
        if ($con->connect_error) {
            die(json_encode(["status" => "failure", "error" => $con->connect_error]));
        }

        // Query to insert data into the database
        $sql = "INSERT INTO request (course, tutor, student, status, date, start, end) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $con->prepare($sql);
        $stmt->bind_param("sssssss", $course, $tutor, $student, $status, $date, $start, $end);

        if ($stmt->execute()) {
            $response = ["status" => "success", "message" => "Request inserted successfully"];
        } else {
            $response = ["status" => "failure", "error" => $stmt->error];
        }

        // Close the statement and connection
        $stmt->close();
        $con->close();
    } else {
        $response = ["status" => "failure", "message" => "Required fields not provided"];
    }

    echo json_encode($response);
}
?>
