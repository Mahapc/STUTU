<?php
// Database connection details
require("conn.php");

// Check connection
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["subject"]) && isset($_POST["sub_subj"])) {
        $subject = $_POST["subject"];
        $sub_subj = $_POST["sub_subj"];

        $sql = "SELECT t.email, t.name, COALESCE(AVG(f.star), 0) AS star, c.course_name, c.id AS course_id 
                FROM course c 
                JOIN tutor t ON c.tutor = t.email 
                LEFT JOIN feedback f ON t.email = f.tutor 
                WHERE c.subject = ? AND c.sub_subj = ? 
                GROUP BY t.name, c.course_name, c.id";

        $stmt = $con->prepare($sql);
        $stmt->bind_param("ss", $subject, $sub_subj);
        $stmt->execute();
        $result = $stmt->get_result();
        $courses = [];

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $courses[] = [
                    "name" => $row["name"],
                    "email" => $row["email"],
                    "star" => round($row["star"], 2),
                    "course_name" => $row["course_name"],
                    "course_id" => $row["course_id"]
                ];
            }
        }

        echo json_encode($courses);
    } else {
        echo json_encode(["error" => "Missing required fields"]);
    }
} else {
    echo json_encode(["error" => "Invalid request"]);
}

$con->close();
?>
