<?php
// Database connection
require("conn.php");

// Check connection
if ($con->connect_error) {
    die(json_encode(["error" => "Connection failed: " . $con->connect_error]));
}

// Check if the request is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["email"], $_POST["gender"], $_POST["age"])) {
        $email = $_POST["email"];
        $gender = $_POST["gender"];
        $age = $_POST["age"];

        // Prepare SQL statement to update gender and age
        $sql = "UPDATE student SET gender = ?, age = ? WHERE email = ?";
        $stmt = $con->prepare($sql);
        $stmt->bind_param("sis", $gender, $age, $email);
        
        if ($stmt->execute()) {
            echo json_encode(["success" => "Profile updated successfully"]);
        } else {
            echo json_encode(["error" => "Failed to update profile"]);
        }

        $stmt->close();
    } else {
        echo json_encode(["error" => "Missing parameters"]);
    }
} else {
    echo json_encode(["error" => "Invalid request method"]);
}

$con->close();
?>
