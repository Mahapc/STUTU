<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Decode the JSON data
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (isset($_POST["email"]) && isset($_POST["password"])) {
        $username = $_POST["email"];
        $password = $_POST["password"];

        // Establish the database connection
        require("conn.php");

        // Check connection
        if ($con->connect_error) {
            die("Connection failed: " . $con->connect_error);
        }

        // Query to check login credentials
        $sql = "SELECT name FROM tutor WHERE email = '$username' AND password = '$password'";
        $result = $con->query($sql);

        if ($result->num_rows > 0) {
            // Fetch the user details
            $row = $result->fetch_assoc();
            
            // Login successful
            $response['status'] = 'success';
            $response['message'] = 'Login successful';
            $response['name'] = $row['name']; // Include the name in the response
        } else {
            // Login failed
            $response['status'] = 'failure';
            $response['message'] = 'Invalid email or password';
        }

        // Close the database connection
        $con->close();
    } else {
        $response['status'] = 'failure';
        $response['message'] = 'Email or password not provided';
    }

    echo json_encode($response);
}
?>
