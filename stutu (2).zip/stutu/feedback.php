<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Decode the JSON data
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (isset($_POST["tutor"]) && isset($_POST["student"]) && isset($_POST["star"]) && isset($_POST["reason"])) {
        $tutor = $_POST["tutor"];
        $student = $_POST["student"];
        $star = $_POST["star"];
        $reason = $_POST["reason"];

        // Establish the database connection
        require("conn.php");

        // Check connection
        if ($con->connect_error) {
            die("Connection failed: " . $con->connect_error);
        }

        // Query to insert data into the database
        $sql = "INSERT INTO feedback (tutor, student, star, reason) VALUES ('$tutor', '$student', '$star', '$reason')";

        if (mysqli_query($con, $sql)) {
            $response['status'] = 'success';
            $response['message'] = 'Feedback inserted successfully';
        } else {
            $response['status'] = 'failure';
            $response['error'] = $con->error;
        }

        // Close the database connection
        $con->close();
    } else {
        $response['status'] = 'failure';
        $response['message'] = 'Required fields not provided';
    }

    echo json_encode($response);
}
?>