<?php
require 'conn.php'; // Include your database connection file

header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['course_id'])) {
    echo json_encode(["error" => "Missing course_id"]);
    exit;
}

$course_id = $data['course_id'];

$sql = "SELECT 
            s.name AS student, 
            c.course_name AS course, 
            r.id,
            r.date, 
            r.start, 
            r.end, 
            r.status, 
            CASE WHEN r.status = 'success' THEN r.link ELSE NULL END AS link
        FROM request r
        JOIN student s ON r.student = s.email
        JOIN course c ON r.course = c.id
        WHERE r.course = ?";

$stmt = $con->prepare($sql);
$stmt->bind_param('i', $course_id);
$stmt->execute();
$result = $stmt->get_result();

$requests = [];
while ($row = $result->fetch_assoc()) {
    $requests[] = $row;
}

$stmt->close();
$con->close();

echo json_encode(["requests" => $requests]);
?>
