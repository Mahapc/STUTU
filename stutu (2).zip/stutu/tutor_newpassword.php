<?php
session_start(); // Start session
include('db.php');
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!empty($_POST['new_password']) ) {
        if (!isset($_SESSION['email'])) { // Ensure session contains email
            echo json_encode(["message" => "Session expired. Please verify OTP again."]);
            exit();
        }

        $email = $_SESSION['email']; // Fetch email from session
        $new_password = $_POST['new_password'];
        

        // Hash the new password for security
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

        // Update password in the signup table
        $update_stmt = $conn->prepare("UPDATE tutor SET password = ? WHERE email = ?");
        $update_stmt->bind_param("ss", $hashed_password, $email);

        if ($update_stmt->execute()) {
            session_destroy(); // Clear session after password reset
            echo json_encode(["message" => "Password reset successful. You can now log in."]);
        } else {
            echo json_encode(["message" => "Error resetting password. Please try again."]);
        }

        $update_stmt->close();
    } else {
        echo json_encode(["message" => "New password and confirm password are required."]);
    }
}
?>
