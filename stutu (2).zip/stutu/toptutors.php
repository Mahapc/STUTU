<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    require("conn.php");
    
    $subject = isset($_POST['subject']) ? trim($_POST['subject']) : '';
    
    if (empty($subject)) {
        echo json_encode(["status" => "failure", "message" => "Subject not provided"]);
        exit;
    }
    
    // Query to fetch tutor names based on their email and their average rating
    $sql = "SELECT t.name AS tutor_name, COALESCE(AVG(f.star), 0) AS avg_rating 
            FROM course c
            LEFT JOIN feedback f ON c.tutor = f.tutor
            LEFT JOIN tutor t ON t.email = c.tutor
            WHERE c.subject = ?
            GROUP BY t.name
            ORDER BY avg_rating DESC";
    
    $stmt = $con->prepare($sql);
    $stmt->bind_param("s", $subject);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $tutors = [];
    while ($row = $result->fetch_assoc()) {
        $tutors[] = [
            "name" => $row["tutor_name"],
            "rating" => round($row["avg_rating"], 2)
        ];
    }
    
    $stmt->close();
    $con->close();
    
    echo json_encode(["status" => "success", "tutors" => $tutors]);
}

?>