<?php
// Database connection details
require("conn.php");

// Check connection
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}

$sql = "SELECT t.name, COALESCE(AVG(f.star), 0) AS star FROM tutor t LEFT JOIN feedback f ON t.email = f.tutor GROUP BY t.email, t.name";

$result = $con->query($sql);

$tutors = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $tutors[] = [
            "name" => $row["name"],
            "star" => round($row["star"], 2)
        ];
    }
}

echo json_encode($tutors);

$con->close();
?>
