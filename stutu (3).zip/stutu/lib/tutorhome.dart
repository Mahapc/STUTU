import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import 'common.dart';
import 'coursecreate.dart';
import 'courserequestpage.dart';

class TutorHomePage extends StatefulWidget {
  const TutorHomePage({super.key});

  @override
  _TutorHomePageState createState() => _TutorHomePageState();
}

class _TutorHomePageState extends State<TutorHomePage> {
  List<Map<String, dynamic>> courses = [];
  bool isLoading = true; // Track loading state

  @override
  void initState() {
    super.initState();
    fetchCourses();
  }

  Future<void> fetchCourses() async {
    String apiUrl = ip+"tutorhome.php"; // Replace with your actual API URL

    try {
      final response = await http.post(
        Uri.parse(apiUrl),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"tutor": id}), // `name` is the tutor's name
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data.containsKey('courses')) {
          setState(() {
            courses = List<Map<String, dynamic>>.from(data['courses']);
            isLoading = false;
          });
        }
      } else {
        throw Exception("Failed to load data");
      }
    } catch (error) {
      print("Error fetching courses: $error");
      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFEF9E7),
      appBar: AppBar(
        backgroundColor: const Color(0xFF6C757D),
        automaticallyImplyLeading: false,
        title: const Text(
          "STUTU....",
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 22,
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 25),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 20),
            Text(
              "Hi $name ....", // Display tutor's name
              style: const TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Color(0xFF1A2D56),
              ),
            ),
            const SizedBox(height: 10),
            Center(
              child: Image.asset(
                'assets/stdh.png',
                height: 200,
                fit: BoxFit.cover,
              ),
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  "My Courses",
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF1A2D56),
                  ),
                ),
                GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const CourseCreatePage(),
                      ),
                    );
                  },
                  child: Row(
                    children: const [
                      Text(
                        "Create new course",
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w500,
                          color: Color(0xFF1A2D56),
                        ),
                      ),
                      SizedBox(width: 5),
                      Icon(Icons.add, color: Color(0xFF1A2D56)),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Expanded(
              child: isLoading
                  ? const Center(child: CircularProgressIndicator()) // Show loader while fetching data
                  : courses.isEmpty
                  ? const Center(child: Text("No courses available"))
                  : ListView.builder(
                itemCount: courses.length,
                itemBuilder: (context, index) {
                  return GestureDetector(
                    onTap: () {
                      cid=courses[index]['id'].toString();
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => CourseRequestPage(),
                        ),
                      );
                    },
                    child: Card(
                      color: const Color(0xFFFFFFFF),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: SizedBox(
                        height: 60,
                        child: ListTile(
                          title: Text(
                            courses[index]['course_name'],
                            style: const TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold),
                          ),
                          trailing: SizedBox(
                            width: 25,
                            height: 25,
                            child: CircleAvatar(
                              backgroundColor: const Color(0xFFD6D6D6),
                              radius: 15,
                              child: Text(
                                courses[index]['count'].toString(),
                                style: const TextStyle(color: Colors.black),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
