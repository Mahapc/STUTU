import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import 'common.dart';
import 'coursespage.dart';

class PhysicsPage extends StatefulWidget {
  @override
  _PhysicsPageState createState() => _PhysicsPageState();
}

class _PhysicsPageState extends State<PhysicsPage> {
  List<Map<String, dynamic>> tutors = [];
  bool isLoading = true;
  bool hasError = false;

  @override
  void initState() {
    super.initState();
    fetchTutors();
  }

  Future<void> fetchTutors() async {
    try {
      final response = await http.post(
        Uri.parse(ip + 'toptutors.php'),
        body: {'subject': 'physics'},
      );

      if (response.statusCode == 200) {
        final Map<String, dynamic> data = json.decode(response.body);

        if (data["status"] == "success") {
          setState(() {
            tutors = List<Map<String, dynamic>>.from(data["tutors"]);
            isLoading = false;
          });
        } else {
          setState(() {
            hasError = true;
            isLoading = false;
          });
        }
      } else {
        setState(() {
          hasError = true;
          isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        hasError = true;
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8F1E7),
      appBar: AppBar(
        backgroundColor: const Color(0xFF6C757D),
        title: const Text("StuTu....", style: TextStyle(color: Colors.white)),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text("Physics", style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.black87)),
              const SizedBox(height: 10),
              Center(
                child: Image.asset('assets/phy.png', width: double.infinity, height: 200, fit: BoxFit.cover),
              ),
              const SizedBox(height: 20),
              const Text("Physics Overview", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.black87)),
              const SizedBox(height: 5),
              const Text("Explore the world of Physics", style: TextStyle(fontSize: 14, color: Colors.black54)),
              const SizedBox(height: 15),
              Center(
                child: _buildCategoryButton(context, "Go to Courses"),
              ),
              const SizedBox(height: 25),
              const Text("Top Tutors", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.black87)),
              const SizedBox(height: 10),
              isLoading
                  ? const Center(child: CircularProgressIndicator())
                  : hasError
                  ? const Center(child: Text("Failed to load tutors"))
                  : tutors.isEmpty
                  ? const Center(child: Text("No tutors available"))
                  : Column(
                children: tutors.map((tutor) => _buildTutorCard(tutor)).toList(),
              ),

            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCategoryButton(BuildContext context, String title) {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF1E2A47), padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12)),
      onPressed: () {

          subject="physics";
          sub_subj="";

        Navigator.push(context, MaterialPageRoute(builder: (context) => CoursePage(title: "Physics")));
      },
      child: Text(title, style: const TextStyle(color: Colors.white, fontSize: 14)),
    );
  }

  Widget _buildTutorCard(Map<String, dynamic> tutor) {
    return Card(
      color: Colors.white,
      elevation: 2,
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: ListTile(
        leading: Image.asset('assets/tutp.png', width: 60, height: 60, fit: BoxFit.cover),
        title: Text(tutor["name"], style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        subtitle: Row(
          children: [
            const Icon(Icons.star, color: Colors.amber, size: 18),
            const SizedBox(width: 5),
            Text(tutor["rating"].toString(), style: const TextStyle(fontSize: 14)),
          ],
        ),
      ),
    );
  }
}