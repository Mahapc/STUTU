import 'package:flutter/material.dart';
import 'package:stutu/studenthome.dart';
import 'package:stutu/stutuaipage.dart';
import 'package:stutu/loginpage.dart';
import 'package:stutu/studentrequest.dart';
import 'package:stutu/tutorprofilepage.dart';

class CustomDrawer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      backgroundColor: const Color(0xFF1E2A47), // Dark Blue
      child: Column(
        children: [
          _buildDrawerHeader(context),
          _buildMenuItem(context, Icons.memory, "Stutu AI"),
          _buildMenuItem(context, Icons.request_page, "Request"),
          _buildMenuItem(context, Icons.person, "My Account"),
          const Spacer(),
          Padding(
            padding: const EdgeInsets.only(bottom: 40),
            child: GestureDetector(
              onTap: () {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => LoginPage()),
                );
              },
              child: const Text(
                "logout",
                style: TextStyle(fontSize: 16, color: Colors.white),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDrawerHeader(BuildContext context) {
    return Container(
      height: 180,
      decoration: const BoxDecoration(
        color: Color(0xFFFBF5E6), // Light Cream
        borderRadius: BorderRadius.only(bottomLeft: Radius.circular(80)),
      ),
      child: Center(
        child: GestureDetector(
          onTap: () {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (context) => StudentHomePage()),
            );
          },
          child: Image.asset(
            'assets/logo.png',
            height: 60,
          ),
        ),
      ),
    );
  }

  Widget _buildMenuItem(BuildContext context, IconData icon, String title) {
    return ListTile(
      leading: Icon(icon, color: Colors.white, size: 28),
      title: Text(
        title,
        style: const TextStyle(fontSize: 18, color: Colors.white),
      ),
      onTap: () {
        Navigator.pop(context);
        if (title == "Stutu AI") {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (_) => StuTuAiPage()),
          );
        } else if (title == "Request") {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => StudentRequestPage()),
          );
        } else if (title == "My Account") {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => ProfilePage()),
          );
        }
      },
    );
  }
}