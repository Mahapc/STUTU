import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import 'package:stutu/editprofile.dart';
import 'common.dart';

class ProfilePage extends StatefulWidget {
  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  String gender = "Loading...";
  String age = "Loading...";

  @override
  void initState() {
    super.initState();
    fetchProfileData();
  }

  // Fetch Gender & Age from the server
  Future<void> fetchProfileData() async {
    final String apiUrl = ip+"studentprof.php"; // Replace with your actual API URL

    try {
      final response = await http.post(
        Uri.parse(apiUrl),
        body: {"email": id}, // 'id' is imported from common.dart
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data.containsKey("gender") && data.containsKey("age")) {
          setState(() {
            gender = data["gender"];
            age = data["age"].toString();
          });
        } else {
          setState(() {
            gender = "Not Available";
            age = "Not Available";
          });
        }
      } else {
        setState(() {
          gender = "Error fetching data";
          age = "Error fetching data";
        });
      }
    } catch (e) {
      setState(() {
        gender = "Network Error";
        age = "Network Error";
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8F1E7),
      appBar: AppBar(
        backgroundColor: const Color(0xFF707070),
        elevation: 0,
        title: const Text(
          "StuTu....",
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
        ),
        centerTitle: false,
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const SizedBox(height: 20),

            // User Profile Heading
            const Align(
              alignment: Alignment.centerLeft,
              child: Text(
                "User Profile",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.black87),
              ),
            ),

            const SizedBox(height: 15),

            // Profile Picture
            Center(
              child: CircleAvatar(
                radius: 50,
                backgroundImage: AssetImage('assets/prof.png'),
              ),
            ),

            const SizedBox(height: 10),

            // Username
            Text(
              name, // From common.dart
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.black87),
            ),

            const SizedBox(height: 20),

            // Email Field
            _buildInfoField("Email", id),

            const SizedBox(height: 15),

            // Gender Field (Fetched from API)
            _buildInfoField("Gender", gender),

            const SizedBox(height: 15),

            // Age Field (Fetched from API)
            _buildInfoField("Age", age),

            const SizedBox(height: 30),

            // Edit Profile Button
            GestureDetector(
              onTap: () {
                ag=age;
                gn=gender;
                Navigator.push(context, MaterialPageRoute(builder: (context) => EditProfile()));
              },
              child: const Text(
                "Edit Profile",
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                  decoration: TextDecoration.underline,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Widget for Info Fields
  Widget _buildInfoField(String label, String value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Colors.black87),
        ),
        const SizedBox(height: 5),
        Container(
          height: 40,
          padding: const EdgeInsets.symmetric(horizontal: 12),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(6),
            boxShadow: [
              BoxShadow(color: Colors.black.withOpacity(0.1), blurRadius: 5),
            ],
          ),
          child: Align(
            alignment: Alignment.centerLeft,
            child: Text(
              value,
              style: const TextStyle(fontSize: 16, color: Colors.black87),
            ),
          ),
        ),
      ],
    );
  }
}
