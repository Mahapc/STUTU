import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:url_launcher/url_launcher.dart';

import 'common.dart';

class CourseRequestPage extends StatefulWidget {


  @override
  State<CourseRequestPage> createState() => _CourseRequestPageState();
}

class _CourseRequestPageState extends State<CourseRequestPage> {
  int selectedCategory = 0; // 0: Pending, 1: Approved, 2: Rejected
  List<Map<String, dynamic>> requests = [];

  @override
  void initState() {
    super.initState();
    fetchRequests();
  }

  Future<void> fetchRequests() async {
    final response = await http.post(
      Uri.parse(ip+'tutorrequest.php'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'course_id': cid}),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      setState(() {
        requests = List<Map<String, dynamic>>.from(data['requests']);
      });
    }
  }

  Future<void> updateRequestStatus(int id, String status, {String? link}) async {
    final response = await http.post(
      Uri.parse(ip+'replyrequest.php'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'id': id, 'status': status, 'link': link}),
    );

    if (response.statusCode == 200) {
      fetchRequests();
    }
  }

  void _showEnterLinkDialog(Map<String, dynamic> request) {
    TextEditingController linkController = TextEditingController();
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          title: const Center(child: Text("Enter Link", style: TextStyle(fontWeight: FontWeight.bold))),
          content: Row(
            children: [
              Expanded(
                child: TextField(
                  controller: linkController,
                  decoration: const InputDecoration(border: OutlineInputBorder(), hintText: "Enter link"),
                ),
              ),
              const SizedBox(width: 10),
              ElevatedButton(
                onPressed: () {
                  if (linkController.text.isNotEmpty) {
                    updateRequestStatus(request['id'], 'success', link: linkController.text);
                    Navigator.pop(context);
                  }
                },
                child: const Text("Send"),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFBF5E6),
      appBar: AppBar(
        backgroundColor: const Color(0xFF6C757D),
        title: const Text("Requests", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 20)),
        leading: IconButton(icon: const Icon(Icons.arrow_back, color: Colors.white), onPressed: () => Navigator.pop(context)),
      ),
      body: Column(
        children: [
          const SizedBox(height: 10),
          _buildCategoryTabs(),
          Expanded(child: _buildRequestList()),
        ],
      ),
    );
  }

  Widget _buildCategoryTabs() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          _categoryButton("Pending", 0),
          _categoryButton("Approved", 1),
          _categoryButton("Rejected", 2),
        ],
      ),
    );
  }

  Widget _categoryButton(String title, int index) {
    return GestureDetector(
      onTap: () => setState(() => selectedCategory = index),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 20),
        decoration: BoxDecoration(
          color: selectedCategory == index ? Colors.blue : Colors.grey[400],
          borderRadius: BorderRadius.circular(20),
        ),
        child: Text(title, style: const TextStyle(color: Colors.white, fontSize: 16)),
      ),
    );
  }

  Widget _buildRequestList() {
    List<Map<String, dynamic>> filteredRequests = requests.where((req) {
      if (selectedCategory == 0) return req['status'] == 'pending';
      if (selectedCategory == 1) return req['status'] == 'success';
      return req['status'] == 'rejected';
    }).toList();

    return ListView.builder(
      itemCount: filteredRequests.length,
      itemBuilder: (context, index) => _buildRequestCard(filteredRequests[index]),
    );
  }

  Widget _buildRequestCard(Map<String, dynamic> request) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(request['student'], style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            Text(request['course'], style: const TextStyle(fontSize: 14)),
            Text(request['date'], style: const TextStyle(fontSize: 14)),
            Text("AT ${request['start']} TO ${request['end']}", style: const TextStyle(fontSize: 14)),
            const SizedBox(height: 10),
            Row(mainAxisAlignment: MainAxisAlignment.end, children: _buildActionButtons(request)),
          ],
        ),
      ),
    );
  }

  List<Widget> _buildActionButtons(Map<String, dynamic> request) {
    if (request['status'] == 'pending') {
      return [
        GestureDetector(onTap: () => _showEnterLinkDialog(request), child: _actionButton(Icons.check_circle, Colors.green)),
        const SizedBox(width: 10),
        GestureDetector(onTap: () => updateRequestStatus(request['id'], 'rejected'), child: _actionButton(Icons.cancel, Colors.red)),
      ];
    } else if (request['status'] == 'success') {
      return [
        _actionButton(Icons.check_circle, Colors.green),
        const SizedBox(width: 10),
        GestureDetector(onTap: () => _openLink(request['link']), child: const Text("View Details", style: TextStyle(color: Colors.blue, fontSize: 14, decoration: TextDecoration.underline))),
      ];
    } else {
      return [_actionButton(Icons.cancel, Colors.red)];
    }
  }
  Widget _actionButton(IconData icon, Color color) {
    return Container(
      decoration: BoxDecoration(
        color: color.withOpacity(0.2),
        shape: BoxShape.circle,
      ),
      padding: const EdgeInsets.all(5),
      child: Icon(icon, color: color, size: 24),
    );
  }
  void _openLink(String url) async {
    if (!await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication)) {
      throw 'Could not launch $url';
    }
  }
}
