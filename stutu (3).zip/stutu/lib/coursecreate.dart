import 'package:flutter/material.dart';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:file_selector/file_selector.dart';

import 'common.dart';

class CourseCreatePage extends StatefulWidget {
  const CourseCreatePage({super.key});

  @override
  _CourseCreatePageState createState() => _CourseCreatePageState();
}

class _CourseCreatePageState extends State<CourseCreatePage> {
  final TextEditingController _courseNameController = TextEditingController();
  final TextEditingController _courseDescriptionController = TextEditingController();
  String? selectedCategory;
  String? selectedSubCategory;
  File? selectedVideo;

  final Map<String, List<String>> subCategories = {
    "Chemistry": ["Organic Chemistry", "Non-Organic Chemistry"],
    "Biology": ["Botany", "Zoology"]
  };

  Future<void> _pickVideo() async {
    const XTypeGroup typeGroup = XTypeGroup(label: 'Videos', extensions: ['mp4', 'mov', 'avi']);
    final XFile? file = await openFile(acceptedTypeGroups: [typeGroup]);

    if (file != null) {
      setState(() {
        selectedVideo = File(file.path);
      });
    }
  }

  Future<void> _uploadCourse() async {
    if (selectedVideo == null || _courseNameController.text.isEmpty || selectedCategory == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Please fill all fields and select a video.")));
      return;
    }

    var request = http.MultipartRequest('POST', Uri.parse(ip+"course_add.php"));
    request.fields['course'] = _courseNameController.text;
    request.fields['tutor'] = id; // Replace with dynamic tutor data
    request.fields['subject'] = selectedCategory!;
    request.fields['sub_subj'] = selectedSubCategory ?? "";
    request.fields['description'] = _courseDescriptionController.text;

    request.files.add(await http.MultipartFile.fromPath('video', selectedVideo!.path));

    var response = await request.send();
    if (response.statusCode == 200) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Course Uploaded Successfully")));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Upload Failed")));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFBF5E6),
      appBar: AppBar(
        backgroundColor: const Color(0xFF6C757D),
        title: const Text(
          "StuTu....",
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 20),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Center(
              child: Text(
                "Course Creation",
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.black),
              ),
            ),
            const SizedBox(height: 20),

            _buildTextField(_courseNameController, "Course Name"),
            const SizedBox(height: 20),

            _buildDropdown("Select Category", selectedCategory, ["physics", "chemistry", "biology"], (value) {
              setState(() {
                selectedCategory = value;
                selectedSubCategory = (value == "Physics") ? "No Sub Category" : null;
              });
            }),
            const SizedBox(height: 20),

            _buildDropdown(
              "Select Sub-category",
              selectedSubCategory,
              (selectedCategory != null && subCategories.containsKey(selectedCategory))
                  ? subCategories[selectedCategory]!
                  : ["No Sub Category"],
                  (value) {
                setState(() {
                  selectedSubCategory = value;
                });
              },
              enabled: selectedCategory == "chemistry" || selectedCategory == "biology",
            ),
            const SizedBox(height: 20),

            _buildTextField(_courseDescriptionController, "Course Description", maxLines: 5),
            const SizedBox(height: 30),

            Center(
              child: Column(
                children: [
                  ElevatedButton.icon(
                    onPressed: _pickVideo,
                    icon: const Icon(Icons.cloud_upload),
                    label: const Text("Upload Video"),
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.blue),
                  ),
                  const SizedBox(height: 10),
                  Text(selectedVideo != null ? "Video Selected: ${selectedVideo!.path.split('/').last}" : "No video selected"),
                  const SizedBox(height: 15),
                  ElevatedButton.icon(
                    onPressed: _uploadCourse,
                    icon: const Icon(Icons.add_circle),
                    label: const Text("Create"),
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTextField(TextEditingController controller, String hintText, {int maxLines = 1}) {
    return TextField(
      controller: controller,
      maxLines: maxLines,
      decoration: InputDecoration(
        hintText: hintText,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
        filled: true,
        fillColor: Colors.white,
      ),
    );
  }

  Widget _buildDropdown(String label, String? value, List<String> items, void Function(String?) onChanged, {bool enabled = true}) {
    return DropdownButtonFormField<String>(
      value: value,
      onChanged: enabled ? onChanged : null,
      decoration: InputDecoration(
        labelText: label,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
        filled: true,
        fillColor: Colors.white,
      ),
      items: items.map((e) => DropdownMenuItem<String>(value: e, child: Text(e))).toList(),
    );
  }
}
