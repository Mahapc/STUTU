import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import 'package:http/http.dart' as http;

import 'customdrawer.dart'; // adjust path if needed

class StuTuAiPage extends StatefulWidget {
  @override
  _StuTuAiPageState createState() => _StuTuAiPageState();
}

class _StuTuAiPageState extends State<StuTuAiPage> {
  final TextEditingController _controller = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  final List<_ChatMessage> _messages = [
    _ChatMessage(text: "HI!!!!!! , HOW CAN I HELP U", isUser: false),
  ];

  // Replace with your backend address
  final String _apiUrl = 'http://172.20.10.5:5000/chat';

  Future<void> _sendMessage() async {
    final text = _controller.text.trim();
    if (text.isEmpty) return;

    setState(() {
      _messages.add(_ChatMessage(text: text, isUser: true));
    });
    _controller.clear();
    _scrollToBottom();

    final historyPayload = _messages
        .map((m) => {'role': m.isUser ? 'user' : 'assistant', 'content': m.text})
        .toList();

    try {
      final resp = await http.post(
        Uri.parse(_apiUrl),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'history': historyPayload, 'message': text}),
      );

      if (resp.statusCode == 200) {
        final data = jsonDecode(resp.body) as Map<String, dynamic>;
        final reply = (data['reply'] ?? '').toString();
        if (reply.isNotEmpty) {
          setState(() {
            _messages.add(_ChatMessage(text: reply, isUser: false));
          });
          _scrollToBottom();
        }
      } else {
        setState(() {
          _messages.add(_ChatMessage(
              text: 'Server error: ${resp.statusCode}', isUser: false));
        });
        _scrollToBottom();
      }
    } catch (e) {
      setState(() {
        _messages
            .add(_ChatMessage(text: 'Connection failed.', isUser: false));
      });
      _scrollToBottom();
    }
  }

  void _scrollToBottom() {
    Future.delayed(const Duration(milliseconds: 100), () {
      _scrollController.animateTo(
        _scrollController.position.maxScrollExtent,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F2E1),
      appBar: AppBar(
        backgroundColor: const Color(0xFF47507F),
        leading: Builder(
          builder: (ctx) => IconButton(
            icon: const Icon(Icons.menu),
            onPressed: () => Scaffold.of(ctx).openDrawer(),
          ),
        ),
        title: const Text(
          'StuTu Ai',
          style: TextStyle(fontWeight: FontWeight.w600),
        ),
      ),
      drawer: CustomDrawer(),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              controller: _scrollController,
              padding: const EdgeInsets.symmetric(vertical: 16),
              itemCount: _messages.length,
              itemBuilder: (context, i) {
                final msg = _messages[i];

                // Build avatar + bubble
                final avatar = CircleAvatar(
                  backgroundImage: AssetImage(
                      msg.isUser ? 'assets/user.png' : 'assets/robot.png'),
                  radius: 16,
                );
                final bubble = Flexible(child: _MessageBubble(text: msg.text));

                return Padding(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 16, vertical: 8),
                  child: Align(
                    alignment: msg.isUser
                        ? Alignment.centerRight
                        : Alignment.centerLeft,
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: msg.isUser
                          ? [
                        bubble,
                        const SizedBox(width: 8),
                        avatar,
                      ]
                          : [
                        avatar,
                        const SizedBox(width: 8),
                        bubble,
                      ],
                    ),
                  ),
                );
              },
            ),
          ),

          // Input area
          Container(
            color: Colors.white,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    onSubmitted: (_) => _sendMessage(),
                    decoration: InputDecoration(
                      hintText: 'Type your message...',
                      filled: true,
                      fillColor: const Color(0xFFEDEDED),
                      contentPadding:
                      const EdgeInsets.symmetric(horizontal: 16),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(24),
                        borderSide: BorderSide.none,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                CircleAvatar(
                  backgroundColor: const Color(0xFF47507F),
                  child: IconButton(
                    icon: const Icon(Icons.send, color: Colors.white),
                    onPressed: _sendMessage,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ChatMessage {
  final String text;
  final bool isUser;
  _ChatMessage({required this.text, required this.isUser});
}

class _MessageBubble extends StatelessWidget {
  final String text;
  const _MessageBubble({required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints:
      BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.7),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: const Color(0xFF2A3B72), width: 1.5),
        borderRadius: BorderRadius.circular(12),
      ),
      child: MarkdownBody(
        data: text,
        styleSheet:
        MarkdownStyleSheet.fromTheme(Theme.of(context)).copyWith(
          p: const TextStyle(fontSize: 14, height: 1.4),
          listBullet: const TextStyle(fontSize: 14),
          strong: const TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
    );
  }
}