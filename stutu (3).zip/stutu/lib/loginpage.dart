import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:stutu/signuppage.dart';
import 'package:stutu/studenthome.dart';
import 'package:stutu/tutorhome.dart';
import 'common.dart';
import 'forgotpassword.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  String _selectedRole = "STUDENT";
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  Future<void> _login() async {
    if (!_formKey.currentState!.validate()) {
      return; // If validation fails, do not proceed
    }

    String email = emailController.text.trim();
    String password = passwordController.text.trim();
    String apiUrl = _selectedRole == "STUDENT"
        ? ip+"studentlogin.php"
        : ip+"tutorlogin.php";

    try {
      var response = await http.post(
        Uri.parse(apiUrl),
        body: {
          "email": email,
          "password": password,
        },
      );

      var data = jsonDecode(response.body);

      if (data['status'] == 'success') {
        id=email;
        String nm = data['name'];
        name=data['name'];
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Welcome, $nm!")),
        );

        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) =>
            _selectedRole == "STUDENT" ? StudentHomePage() : TutorHomePage(),
          ),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(data['message'])),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("An error occurred. Please try again.")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFEF9E7),
      body: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              const SizedBox(height: 80),
              const Text(
                "Welcome To StuTu",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF1A2D56),
                ),
              ),
              const SizedBox(height: 25),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _roleButton("STUDENT"),
                  const SizedBox(width: 10),
                  _roleButton("TUTOR"),
                ],
              ),
              const SizedBox(height: 25),
              _textField("Enter your email", emailController, isEmail: true),
              const SizedBox(height: 15),
              _textField("Enter your password", passwordController, isPassword: true),
              const SizedBox(height: 60),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF1A2D56),
                  padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 100),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                onPressed: _login,
                child: const Text("LOGIN", style: TextStyle(color: Colors.white, fontSize: 16)),
              ),
              const SizedBox(height: 15),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [

                  GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => SignupPage()),
                      );
                    },
                    child: Row(
                      children: const [
                        Text("Create an Account", style: TextStyle(fontWeight: FontWeight.bold)),
                        SizedBox(width: 5),
                        Icon(Icons.add_circle_outline, size: 20, color: Colors.black),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 100),
              Image.asset(
                'assets/log.png', // Replace with actual image path
                height: 270,
                fit: BoxFit.cover,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _roleButton(String role) {
    bool isSelected = _selectedRole == role;
    return GestureDetector(
      onTap: () {
        setState(() {
          _selectedRole = role;
        });
      },
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 30),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFF1A2D56) : Colors.black,
          borderRadius: BorderRadius.circular(5),
        ),
        child: Text(
          role,
          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }

  Widget _textField(String hint, TextEditingController controller,
      {bool isPassword = false, bool isEmail = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: TextFormField(
        controller: controller,
        obscureText: isPassword,
        keyboardType: isEmail ? TextInputType.emailAddress : TextInputType.text,
        decoration: InputDecoration(
          hintText: hint,
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide.none,
          ),

        ),
        validator: (value) {
          if (value == null || value.isEmpty) {
            return "This field cannot be empty";
          }
          if (isEmail && !RegExp(r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$").hasMatch(value)) {
            return "Enter a valid email";
          }
          return null;
        },
      ),
    );
  }
}
